#!/usr/bin/env bash
# Post-King Chess one-click install. Counted download via this project's Worker.
# Usage: curl -fsSL https://postking-download-tracker.vibelock.workers.dev/install.sh | bash
set -euo pipefail

HOST="${POSTKING_HOME_HOST:-https://postking-download-tracker.vibelock.workers.dev}"
ASSET="${POSTKING_HOME_ASSET:-postking-chess-0.1.0.tar.gz}"
WORKDIR="${POSTKING_HOME:-$HOME/postking-chess}"

mkdir -p "$WORKDIR"
cd "$WORKDIR"

echo "Downloading counted tarball from ${HOST}/download (User-Agent Mozilla/5.0)…"
curl -fsSL -A 'Mozilla/5.0' "${HOST}/download?asset=${ASSET}" -o "${ASSET}"

tar -xzf "${ASSET}"
DIR="$(find . -maxdepth 1 -type d \( -name 'postking-chess-*' -o -name 'postking_chess-*' \) | head -n 1)"
if [ -n "${DIR}" ]; then
  cd "${DIR}"
fi

python3 -m venv .venv
# shellcheck disable=SC1091
. .venv/bin/activate
python -m pip install -U pip
python -m pip install -e .

echo
echo "Installed Post-King Chess."
echo "Run:  postking ui"
echo "Then open http://127.0.0.1:8844  (loopback only)"
echo "Author: Aziel Eliab."
